// PTUpdateObject.h: interface for the CPTUpdateObject class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PTUPDATEOBJECT_H__E8D03500_5160_11D6_B756_000476915EC7__INCLUDED_)
#define AFX_PTUPDATEOBJECT_H__E8D03500_5160_11D6_B756_000476915EC7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPTUpdateObject  
{
public:
	CPTUpdateObject();
	virtual ~CPTUpdateObject();

};

#endif // !defined(AFX_PTUPDATEOBJECT_H__E8D03500_5160_11D6_B756_000476915EC7__INCLUDED_)
